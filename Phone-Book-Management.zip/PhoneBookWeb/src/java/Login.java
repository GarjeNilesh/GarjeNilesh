import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Login")
public class Login extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        // Retrieve email and password from the login form
        String email = request.getParameter("email");
        String password = request.getParameter("password");
           
         if (email == null || email.isEmpty() || password == null || password.isEmpty()) {
        out.println("<script>alert('Email and password cannot be empty. Please try again.');</script>");
        response.sendRedirect("login.jsp");
        return; 
    }
        // Validate the login credentials against the database
        boolean isValidUser = validateUser(email, password);

        if (isValidUser) {
             
             HttpSession session = request.getSession();
             session.setAttribute("loginSuccess", true);
             response.sendRedirect("index.jsp");
         
           } else {
            
            HttpSession session = request.getSession();
            session.setAttribute("loginError", true);
           
            response.sendRedirect("login.jsp");
        }
    }

    // Method to validate user credentials against the database
    private boolean validateUser(String email, String password) {
        boolean isValid = false;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            // Establish database connection (replace the connection URL, username, and password with your own)
             conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/phonebook", "postgres", "postgres");
         
            // Prepare SQL query to check if the user exists with the provided email and password
            String query = "SELECT * FROM \"user\" WHERE email = ? AND password = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, email);
            ps.setString(2, password);
            
            
            // Execute the query
            rs = ps.executeQuery();
            
            // Check if the query returned any rows
            if (rs.next()) {
                isValid = true; // User exists with the provided credentials
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return isValid;
    }
}
