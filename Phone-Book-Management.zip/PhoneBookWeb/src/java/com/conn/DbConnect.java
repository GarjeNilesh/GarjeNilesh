/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.conn;

import java.sql.*;


/**
 *
 * @author Nilesh
 */
public class DbConnect {
    
    private static Connection conn;
    
    public static Connection getConn(){
    
    try{
        conn = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/phonebook", "postgres", "postgres");
    }catch(Exception e){
        e.printStackTrace();
    
       
    }
     return conn;
    }
}
    

