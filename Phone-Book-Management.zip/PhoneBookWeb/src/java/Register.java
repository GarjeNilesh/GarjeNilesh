import java.io.*;
import java.sql.*;
import java.util.Timer;
import java.util.TimerTask;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


@WebServlet(urlPatterns = {"/Register"})
public class Register extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try { Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/phonebook", "postgres", "postgres");
            PreparedStatement ps = con.prepareStatement(
                    "insert into \"user\"(name,email,password) values(?,?,?)");
        // PreparedStatement ps = con.prepareStatement("INSERT INTO \"user\" (name, email, password) VALUES (?, ?, ?)");

            ps.setString(1, name); // Corrected index from 2 to 1
            ps.setString(2, email); // Corrected index from 3 to 2
            ps.setString(3, password); // Corrected index from 4 to 3

            int i = ps.executeUpdate();

          
                if (i > 0) {
                request.setAttribute("registrationSuccess", true);
               // Forward the request to a success page or back to the registration page
               request.getRequestDispatcher("register.jsp").forward(request, response);
            }
         
            
        } catch (Exception e2) {
           
            e2.printStackTrace();
        }
        finally {
            out.close();
        }
    }
}
