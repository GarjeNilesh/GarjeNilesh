import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/AddContact"})
public class AddContact extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String no = request.getParameter("no");

        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/phonebook", "postgres", "postgres");
            PreparedStatement ps = con.prepareStatement("insert into contact(name,email,no) values(?,?,?)");

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, no);

            int i = ps.executeUpdate();

            if (i > 0) {
              
                request.setAttribute("registrationSuccess", true);
                request.getRequestDispatcher("addContact.jsp").forward(request, response);
            //   response.sendRedirect("addContact.jsp");
            
            } else {
                // Handle the case where the contact could not be added
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the exception gracefully (e.g., display an error message)
        }
    }
}
